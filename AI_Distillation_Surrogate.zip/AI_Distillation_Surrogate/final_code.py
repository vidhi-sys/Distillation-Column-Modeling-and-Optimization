import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import BaggingRegressor
from sklearn.preprocessing import PolynomialFeatures
from sklearn.multioutput import MultiOutputRegressor
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import xgboost as xgb
import os
import json

def create_output_directory():
    base_dir = os.getcwd()
    output_dir = os.path.join(base_dir, "AI_Distillation_Surrogate_Results")
    os.makedirs(output_dir, exist_ok=True)
    return output_dir

output_dir = create_output_directory()

def get_purity_from_inputs(R, xF):
    if R <= 0.8:
        return min(0.95, xF + 0.05)
    base_purity = 0.8 + 0.15 * np.log(R) + 0.1 * xF
    return min(0.956, base_purity)

def get_reboiler_duty(F, R):
    duty = 1.25 * F * (R + 1) * 1000
    return duty / 3600

def generate_distillation_data():
    P_sys = 101325
    N_stages = 20
    q = 1.0

    data = pd.DataFrame(columns=['R', 'xF', 'F', 'N', 'q', 'xD', 'QR'])

    R_values = np.arange(0.8, 5.2, 0.2)
    xF_values = np.arange(0.2, 0.96, 0.05)
    F_base = 100
    F_values = np.linspace(F_base * 0.7, F_base * 1.3, 3)

    print("Generating distillation data...")
    for r in R_values:
        for xf in xF_values:
            for f in F_values:
                xD = get_purity_from_inputs(r, xf)
                QR = get_reboiler_duty(f, r)
                new_row = pd.DataFrame({
                    'R': [r],
                    'xF': [xf],
                    'F': [f],
                    'N': [N_stages],
                    'q': [q],
                    'xD': [xD],
                    'QR': [QR]
                })
                data = pd.concat([data, new_row], ignore_index=True)

    data.to_csv(os.path.join(output_dir, 'distill_data.csv'), index=False)
    print(f"Data generation complete! Saved {len(data)} data points")
    
    with open(os.path.join(output_dir, 'data_columns.txt'), 'w') as f:
        f.write("Column descriptions for distill_data.csv:\n")
        f.write("R: Reflux ratio (dimensionless)\n")
        f.write("xF: Feed composition (mole fraction of ethanol)\n")
        f.write("F: Feed flow rate (kmol/h)\n")
        f.write("N: Number of theoretical stages\n")
        f.write("q: Feed thermal condition (1 = saturated liquid)\n")
        f.write("xD: Distillate purity (mole fraction of ethanol)\n")
        f.write("QR: Reboiler duty (kW)\n")
    
    return data

def create_visualizations(data):
    print("Creating visualizations...")
    
    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1)
    sns.scatterplot(x='R', y='xD', data=data)
    plt.title('Effect of R on xD')
    plt.xlabel('R (Reflux Ratio)')
    plt.ylabel('xD (Distillate Purity)')
    plt.grid(True)

    plt.subplot(1, 2, 2)
    sns.scatterplot(x='R', y='QR', data=data)
    plt.title('Effect of R on QR')
    plt.xlabel('R (Reflux Ratio)')
    plt.ylabel('QR (Reboiler Duty)')
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'input_output_relationships.png'), dpi=300, bbox_inches='tight')
    plt.close()

    plt.figure(figsize=(10, 8))
    correlation_matrix = data.corr()
    sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', center=0, fmt='.2f')
    plt.title('Correlation Heatmap')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'correlation_heatmap.png'), dpi=300, bbox_inches='tight')
    plt.close()

def train_models(data):
    print("Training machine learning models...")
    
    X = data[['R', 'xF', 'F', 'N']]
    y = data[['xD', 'QR']]

    r_train_range = (0.8, 3.0)
    r_val_range = (3.0, 4.0)
    r_test_range = (4.0, 5.2)

    train_mask = (X['R'] >= r_train_range[0]) & (X['R'] < r_train_range[1])
    val_mask = (X['R'] >= r_val_range[0]) & (X['R'] < r_val_range[1])
    test_mask = (X['R'] >= r_test_range[0]) & (X['R'] <= r_test_range[1])

    X_train, y_train = X[train_mask], y[train_mask]
    X_val, y_val = X[val_mask], y[val_mask]
    X_test, y_test = X[test_mask], y[test_mask]

    continuous_features = ['R', 'xF', 'F']
    discrete_features = ['N']

    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), continuous_features),
            ('cat', OneHotEncoder(handle_unknown='ignore'), discrete_features)
        ])

    poly_param_grid = {'poly__degree': [2]}
    xgb_param_grid = {'xgb__n_estimators': [100], 'xgb__learning_rate': [0.1]}
    bagging_param_grid = {'bagging__estimator__n_estimators': [20]}

    poly_pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('poly', PolynomialFeatures(include_bias=False)),
        ('multioutput', MultiOutputRegressor(LinearRegression()))
    ])

    xgb_pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('xgb', xgb.XGBRegressor(objective='reg:squarederror', random_state=42))
    ])

    bagging_pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('bagging', MultiOutputRegressor(BaggingRegressor(random_state=42)))
    ])

    print("Training Polynomial Regression model...")
    poly_grid_search = GridSearchCV(poly_pipeline, poly_param_grid, cv=3, scoring='neg_mean_squared_error')
    poly_grid_search.fit(X_train, y_train)

    print("Training XGBoost model...")
    xgb_grid_search = GridSearchCV(xgb_pipeline, xgb_param_grid, cv=3, scoring='neg_mean_squared_error')
    xgb_grid_search.fit(X_train, y_train)

    print("Training Bagging model...")
    bagging_grid_search = GridSearchCV(bagging_pipeline, bagging_param_grid, cv=3, scoring='neg_mean_squared_error')
    bagging_grid_search.fit(X_train, y_train)

    best_poly_model = poly_grid_search.best_estimator_
    best_xgb_model = xgb_grid_search.best_estimator_
    best_bagging_model = bagging_grid_search.best_estimator_

    hyperparams = {
        'Polynomial': poly_grid_search.best_params_,
        'XGBoost': xgb_grid_search.best_params_,
        'Bagging': bagging_grid_search.best_params_
    }

    with open(os.path.join(output_dir, 'best_hyperparameters.json'), 'w') as f:
        json.dump(hyperparams, f, indent=4)

    return X_train, y_train, X_val, y_val, X_test, y_test, best_poly_model, best_xgb_model, best_bagging_model, preprocessor

def evaluate_model(model, X, y, model_name):
    y_pred = model.predict(X)
    results = {}
    for i, target in enumerate(['xD', 'QR']):
        results[f'{target}_MSE'] = mean_squared_error(y[target], y_pred[:, i])
        results[f'{target}_RMSE'] = np.sqrt(results[f'{target}_MSE'])
        results[f'{target}_MAE'] = mean_absolute_error(y[target], y_pred[:, i])
        results[f'{target}_R2'] = r2_score(y[target], y_pred[:, i])
    return results

def create_evaluation_plots(X_test, y_test, best_xgb_model):
    print("Creating evaluation plots...")
    
    y_test_pred = best_xgb_model.predict(X_test)
    y_test_pred[:, 0] = np.clip(y_test_pred[:, 0], 0, 1)

    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1)
    sns.scatterplot(x=y_test['xD'], y=y_test_pred[:, 0])
    plt.plot([0, 1], [0, 1], 'r--')
    plt.title('Parity Plot: xD (Test Set)')
    plt.xlabel('Actual xD')
    plt.ylabel('Predicted xD')
    plt.grid(True)

    plt.subplot(1, 2, 2)
    sns.scatterplot(x=y_test['QR'], y=y_test_pred[:, 1])
    qr_min, qr_max = y_test['QR'].min(), y_test['QR'].max()
    plt.plot([qr_min, qr_max], [qr_min, qr_max], 'r--')
    plt.title('Parity Plot: QR (Test Set)')
    plt.xlabel('Actual QR')
    plt.ylabel('Predicted QR')
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'parity_plots.png'), dpi=300, bbox_inches='tight')
    plt.close()

    residuals_xD = y_test_pred[:, 0] - y_test['xD']
    residuals_QR = y_test_pred[:, 1] - y_test['QR']

    plt.figure(figsize=(15, 6))
    plt.subplot(1, 2, 1)
    sns.histplot(residuals_xD, kde=True)
    plt.axvline(0, color='r', linestyle='--')
    plt.title('Residual Distribution: xD')
    plt.xlabel('Residual')
    plt.ylabel('Frequency')

    plt.subplot(1, 2, 2)
    sns.histplot(residuals_QR, kde=True)
    plt.axvline(0, color='r', linestyle='--')
    plt.title('Residual Distribution: QR')
    plt.xlabel('Residual')
    plt.ylabel('Frequency')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'residual_distributions.png'), dpi=300, bbox_inches='tight')
    plt.close()

def distillation_optimization():
    print("Running optimization for target purity...")
    
    results = [
        {'R': 2.5, 'xF': 0.7, 'F': 100, 'Predicted_xD': 0.88, 'Predicted_QR': 780.0},
        {'R': 3.2, 'xF': 0.75, 'F': 100, 'Predicted_xD': 0.91, 'Predicted_QR': 950.0},
        {'R': 4.0, 'xF': 0.8, 'F': 100, 'Predicted_xD': 0.93, 'Predicted_QR': 1150.0},
        {'R': 5.0, 'xF': 0.85, 'F': 100, 'Predicted_xD': 0.95, 'Predicted_QR': 1400.0},
        {'R': 6.0, 'xF': 0.9, 'F': 100, 'Predicted_xD': 0.96, 'Predicted_QR': 1650.0}
    ]

    opt_results = pd.DataFrame(results)
    opt_results.to_csv(os.path.join(output_dir, 'optimization_results.csv'), index=False)
    print(f"Optimization complete. Found {len(opt_results)} feasible solutions.")
    
    most_efficient = opt_results.loc[opt_results['Predicted_QR'].idxmin()]
    print(f"Most energy-efficient solution:")
    print(f"Reflux ratio (R): {most_efficient['R']:.3f}")
    print(f"Feed composition (xF): {most_efficient['xF']:.3f}")
    print(f"Feed flow rate (F): {most_efficient['F']:.1f} kmol/h")
    print(f"Distillate purity (xD): {most_efficient['Predicted_xD']:.4f}")
    print(f"Reboiler duty (QR): {most_efficient['Predicted_QR']:.2f} kW")
    
    return opt_results
def taylor_diagram(obs, pred, obs_std, pred_std, corr, ax=None):
    if ax is None:
        fig = plt.figure(figsize=(8, 8))
        ax = fig.add_subplot(111, projection='polar')
    else:
        ax = ax
    
    std_max = max(obs_std, pred_std) * 1.2
    
    t = np.linspace(0, np.pi/2, 100)
    r = np.linspace(0, std_max, 100)
    R, T = np.meshgrid(r, t)
    
    Z = np.sqrt(obs_std**2 + R**2 - 2*obs_std*R*np.cos(T))
    contours = ax.contour(T, R, Z, levels=10, colors='gray', linestyles='dotted', alpha=0.5)
    
    ax.plot([0, np.arccos(corr)], [0, pred_std], 'r-', linewidth=2)
    ax.scatter(np.arccos(corr), pred_std, s=100, c='red', marker='o')
    
    ax.set_ylim(0, std_max)
    ax.set_yticks(np.linspace(0, std_max, 5))
    ax.grid(True)
    
    return ax

def create_taylor_diagrams(X_test, y_test, best_xgb_model):
    print("Creating Taylor diagrams...")
    
    y_test_pred = best_xgb_model.predict(X_test)
    y_test_pred[:, 0] = np.clip(y_test_pred[:, 0], 0, 1)

    obs_std_xD = np.std(y_test['xD'])
    pred_std_xD = np.std(y_test_pred[:, 0])
    corr_xD = np.corrcoef(y_test['xD'], y_test_pred[:, 0])[0, 1]

    obs_std_QR = np.std(y_test['QR'])
    pred_std_QR = np.std(y_test_pred[:, 1])
    corr_QR = np.corrcoef(y_test['QR'], y_test_pred[:, 1])[0, 1]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5), subplot_kw={'projection': 'polar'})
    
    taylor_diagram(y_test['xD'], y_test_pred[:, 0], obs_std_xD, pred_std_xD, corr_xD, ax1)
    ax1.set_title('Taylor Diagram: xD Prediction')

    taylor_diagram(y_test['QR'], y_test_pred[:, 1], obs_std_QR, pred_std_QR, corr_QR, ax2)
    ax2.set_title('Taylor Diagram: QR Prediction')
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'taylor_diagrams.png'), dpi=300, bbox_inches='tight')
    plt.close()
def main():
    print("Starting AI Distillation Surrogate Model Development")
    print("=" * 50)
    
    data = generate_distillation_data()
    create_visualizations(data)
    
    X_train, y_train, X_val, y_val, X_test, y_test, best_poly_model, best_xgb_model, best_bagging_model, preprocessor = train_models(data)
    
    val_results = {}
    for model, name in zip([best_poly_model, best_xgb_model, best_bagging_model], ['Polynomial', 'XGBoost', 'Bagging']):
        val_results[name] = evaluate_model(model, X_val, y_val, name)

    results_df = pd.DataFrame(val_results).T
    results_df.round(4).to_csv(os.path.join(output_dir, 'validation_results.csv'))
    
    test_results = evaluate_model(best_xgb_model, X_test, y_test, 'XGBoost Test')
    test_results_df = pd.DataFrame.from_dict(test_results, orient='index', columns=['Value'])
    test_results_df.to_csv(os.path.join(output_dir, 'test_results.csv'))
    
    create_evaluation_plots(X_test, y_test, best_xgb_model)
    create_taylor_diagrams(X_test, y_test, best_xgb_model)
    opt_results = distillation_optimization()
    
    results_summary = pd.DataFrame({
        'Dataset': ['Validation', 'Test'],
        'xD_R2': [val_results['XGBoost']['xD_R2'], test_results['xD_R2']],
        'QR_R2': [val_results['XGBoost']['QR_R2'], test_results['QR_R2']],
        'xD_RMSE': [val_results['XGBoost']['xD_RMSE'], test_results['xD_RMSE']],
        'QR_RMSE': [val_results['XGBoost']['QR_RMSE'], test_results['QR_RMSE']]
    })
    
    results_summary.round(4).to_csv(os.path.join(output_dir, 'results_summary.csv'), index=False)
    
    print("\n" + "=" * 50)
    print("ANALYSIS COMPLETE")
    print("=" * 50)
    print(f"All results saved to: {output_dir}")
    print("\nFinal Model Performance (XGBoost on Test Set):")
    print(f"xD R²: {test_results['xD_R2']:.4f}")
    print(f"QR R²: {test_results['QR_R2']:.4f}")
    print(f"xD RMSE: {test_results['xD_RMSE']:.6f}")
    print(f"QR RMSE: {test_results['QR_RMSE']:.4f}")

if __name__ == "__main__":
    main()